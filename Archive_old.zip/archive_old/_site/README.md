Github pages to showcase personal projects and a blogroll discussing data and visualisations

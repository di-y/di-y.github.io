---
layout:     post
title:      The El Classico of Cricket - India vs Pakistan - World Cup 2015
date:       2015-07-28 12:31:19
summary:    India vs Pakistan world cup staistics
categories: sports
thumbnail: trophy
tags:
 - india
 - pakistan
 - world cup
 - cricket
 - sports
 - data
 - analysis
 - data is beautiful
---

><a href="http://imgur.com/jDr1LfG"><img src="http://i.imgur.com/jDr1LfG.jpg" title="el classico cricket" /></a>
<a title="" href="http://www.starsports.com/cricket/columns/harsha-bhogle-126/article=icc-cricket-world-cup-2015-india-pakistan-when-fear-makes-even-the-mighty-look-ordinary/index.html">India vs Pakistan: When fear makes even the mighty look ordinary</a>

Hands down the greatest rivalry in cricket world, excitement levels this match has to offer for millions of cricket supporters around the globe is much more than any other sports battle. According to the International Cricket Council (ICC), tickets for this particular match were sold out in the starting 20 minutes of its sale. Wo-ah thats quick.

Considering the world cup, its been a one way journey for INDIA, <strong>5 consecutive wins in last 23 years</strong>. India has never lost to Pakistan in the World Cups, Can you guess the team which is yet to be defeated by India ? (Scroll down for the answer). Its a fresh tournament in the new mecca of cricket in which Pakistan will feel more homely, after all they won the 1992 World Cup in Australia itself (The only moral booster in this case) under the captaincy of Imran Khan. Indians despite losing this World Cup defeated Pakistan in a match everyone remembers (The Prasad - Sohail battle). Out of these five world cup wins which India recorded, two of them have been in India itself while rest have been at a neutral venue. In 4 out of these 5 matches, <strong>India won the toss</strong> and decided to have a bat. <strong>The run difference in these wins has always been less than 50</strong> (Closely fought battles).

Nowadays, with the new rules in place, the DRS, and possibly with the extinctionof Reverse Swing, cricket is considered a game tailor made for batsmen. So lets have a look at our batsmen who fought these battles hard. <strong>Sachin Tendulkar</strong> has the maximum(313) runs and is the only person to have played all 5matches. He is then followed by <strong>Azharuddin and our timeless steel Rahul Dravid</strong> with 118 and 105 runs respectively. <strong>Yuvraj Singh</strong> has the highest strike rate of 93 followed by <strong>S. Raina</strong>. As a matter of fact, <strong>no India player has scored a century in a World Cup clash with Pakistan</strong>. Lets wait and watch the Kohli's and Rahane's destroying these records soon.

Pakistan as always is considered a good bowling unit with several gems in their armour. But lets have a look at some of the Indian bowlers who have always delivered in these historical clashes. <strong>Venkatesh Prasad</strong> is best of the lot, 8 wickets with a career best of 27/5. He is then followed by <strong>Srinath (7), Kumble (5), Khan (4) and Nehra (4).</strong>

Talking about the current scenario, India holds a <strong>second position</strong> with 114 points in the ICC ODI team rankings whereas Pakistan are lagging at a No. 7 position with 94 points*. <strong>Four (4) Indian batsmen hold a spot inthe top 15 ICC batsmen rankings</strong>, whereas only 1 batsman from Pak has managed to fetch a place here. Considering the bowlers, though Pakistan holds a top spot here with Saeed Ajmal (1),  but the ace has been pulled out of World Cup because of his bowling action. India as expected holds the 13th and 14th position in this list with B. Kumar and R. Jadeja.

All said and done, everything is history, it is a big day for two teams startingtheir world cup campaigns. Lets see whether India makes it 6-0 or is it Pakistanwho will taste their fist ever world cup victory against India. Whatever the result is, this match is a treat, Don't Miss :)
And yeah, <strong>We won't give it back!!</strong>

**PS: India has never defeated South Africa in a World Cup match**

> Ratings as on 15th Feb, 2015

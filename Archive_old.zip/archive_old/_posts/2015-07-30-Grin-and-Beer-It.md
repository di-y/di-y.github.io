---
layout:     post
title:      DataVis Stories - Grin and Beer It!!
comments: true
date:       2015-07-30 12:31:19
summary:    Best pubs in Bangalore represented visually.
categories: datavisualisation
thumbnail: beer
tags:
 - beer
 - visualisations
 - data
 - analysis
 - data is beautiful
---

The **`pub capital of India`**, a moniker the city earned in the 1990s for the sheer number of pubs that sprang up in that decade, has stayed with it despite the pre-midnight closing deadline for bars. Grin and beer it, is the way of life and Win or lose, there's only one way to celebrate a match in Bangalore.

>Keep yourself updated and informed with this visual about the best pubs currently in the city. Though, there are several locations with a good rating where you can chill out without breaking the bank, but just loose your pockets a bit to enjoy the best.

<a href="http://imgur.com/UHPxQXK"><img src="http://i.imgur.com/UHPxQXK.png" title="Best pubs in Bangalore" /></a>

Any favourites ?

><strong>Note</strong>: I have used <em><a href="https://www.zomato.com" target="_blank">Zomato</a></em> for the data and it is limited to top 60 pubs in Bangalore as of June 25, 2015.
